from tkinter import *
import random
import re
import os
alphaUC = "QWERTYUIOPASDFGHJKLZXCVBNM"
class GameLevel:
    def __init__(self, levelNum = '', answer = '') -> None:
        #LEVEL DETAILS INITIALIZATION
        self.buttons_Dict = {}
        self.levelNum = levelNum
        self.answer = answer

        #GENERATE KEYS FOR RIGHT ANSWERS AND ADD RANDOM CHARS FOR THE REMAINING CHOICES
        self.char_List = []
        for x in self.answer:
            x = x.upper()
            if x not in self.char_List:
                self.char_List.append(x)
            else:
                count = self.char_List.count(x)
                while f'{x}{count}' in self.char_List:
                    count+=1
                self.char_List.append(f'{x}{count}')

        for x in range((12 - len(self.char_List))):
            newChar = alphaUC[random.randint(0, len(alphaUC)) - 1].upper()
            while newChar in self.char_List:
                newChar = alphaUC[random.randint(0, len(alphaUC)) - 1].upper()
            self.char_List.append(newChar)
        random.shuffle(self.char_List)

    def create_TextField(self, master = None):
        #TEXT FIELD POSITIONING
        textField_Frame = Frame(master, background='#212737')
        textField_Frame.pack( )
        self.textBox_List = [TextBox(textField_Frame) for _ in range(len(self.answer))]
        return self.textBox_List

    def create_Keys(self, master = None):
        keys_Frame = Frame(master=master, background='#212737')
        keys_Frame.pack(pady=5)
        for x in self.char_List:
            self.buttons_Dict[x] = RoundedButton(keys_Frame, char=x)
        return self.buttons_Dict

class ProgressBar(Frame):
    def __init__(self, master, level = '1', coins = 100):
        super().__init__(master)
        #TOP FRAME --> COINS AND LEVEL INDICATION
        self.level = level
        self.coins = coins

        self.config(width=500, height=50, background='#4471c4')
        self.pack_propagate(0)

        self.level_label = Label(self, text=f"LEVEL: {self.level}", font="awesome 20 bold", bg='#4471c4', fg='white')
        self.level_label.place(x=20, y=8)

        self.coin_image = PhotoImage(file=f"{os.getcwd()}\\assets\\coins_icon.png").subsample(x=75, y=75)
        self.coins_ImageLabel = Label(self, image=self.coin_image, background='#4471c4').place(x=380, y=3)

        self.coins_label = Label(self, text=f'{self.coins}', font="awesome 25 bold", bg='#4471c4', fg='white')
        self.coins_label.place(x=420, y=2)

    def Update(self, level = 0, coins = 0):
        self.coins_label.config(text=coins)
        self.level_label.config(text=f'LEVEL: {level}')

class MenuPrompt(Canvas):
    def __init__(self, master):
        super().__init__(master=master)
        self.master = master
        self.img = PhotoImage(file=f'{os.getcwd()}\\assets\\menu_frame.png')
        self.config(width=306, height=407, highlightthickness=0)
        self.create_image(306/2, 407/2, image=self.img)
        
        self.create_Menu()
    
    def create_Menu(self):
        self.menu_frame = Frame(self)
        self.menu_frame.config(background='#fff568')
        self.credit_frame = Frame(self)
        self.credit_frame.config(background='#fff568')

        self.button_img = PhotoImage(file=f'{os.getcwd()}\\assets\\play_again_button.png')
        Button(self.menu_frame, image=self.button_img, command=self.restart_Game,background='#fff568', activebackground='#fff568', border=0).pack(pady=10)
        self.credits_img = PhotoImage(file=f'{os.getcwd()}\\assets\\credits.png')
        Button(self.menu_frame, image=self.credits_img, command= self.create_Credits,background='#fff568', activebackground='#fff568', border=0).pack()
        self.quit_img = PhotoImage(file=f'{os.getcwd()}\\assets\\quit_button.png')
        Button(self.menu_frame, image=self.quit_img, command=lambda: self.master.destroy(), background='#fff568', activebackground='#fff568', border=0).pack(pady=10)
        self.create_window(306/2, 200, window=self.menu_frame)
    
    def create_Credits(self):
        self.menu_frame.destroy()

        Message(self.credit_frame, text='Coded By:\nKhodie Rion Malig\n\nAssets By:\n Vincent Gilbert Nunez\n\nBug Tested By:\nVincent Gilbert Nunez\nVincent Robert Soto', justify=CENTER, font='awesome 15', background='#fff568', fg='white').pack()
        self.create_window(306/2, 200, window=self.credit_frame)

        self.after(2800, lambda: self.credit_frame.destroy())
        self.after(3000, self.create_Menu)

    def restart_Game(self):
        self.destroy()
        self.master.coins = 100
        self.master.level = 1
        self.master.update_Game()
class RevealPrompt(Canvas):
    def __init__(self, master, msg = ''):
        super().__init__(master)
        self.msg = msg
        self.config(width=167, height=67, background='#212737',highlightthickness=0)
        self.img = PhotoImage(file=f'{os.getcwd()}\\assets\\reveal_prompt.png')
        self.width = self.img.width()
        self.height = self.img.height()
        self.create_image(self.width/2, self.height/2, image=self.img)
        Label(self, text=self.msg, font='awesome 12 bold', background='white').place(x=self.width/2, y=(self.height/2) - 8, anchor=CENTER)
        self.after(2000, lambda: self.destroy())
        
class RoundedButton(Button):
    def __init__(self, master, char, **kwargs):
        super().__init__(master=master, **kwargs)
        self.buttonDir = f"{os.getcwd()}\\assets\\button_template.png"
        self.image = PhotoImage(file=self.buttonDir).subsample(x=7, y=7)
        self.config(image=self.image, relief=FLAT, text=re.sub(r'[1-9]', '', char), font="awesome 25 bold", border = 0, background='#212737', activebackground='#212737',compound=CENTER)

class TextBox(Label):
    def __init__(self, master):
        super().__init__(master=master)
        self.charID = ' '
        self.__curDir = f"{os.getcwd()}\\assets\\input_box.png"
        self.__image = PhotoImage(file=self.__curDir).subsample(x=7, y=7)
        self.config(image=self.__image, relief=FLAT, text=' ',font="awesome 25 bold", border = 0, background='#212737', foreground='white', compound=CENTER)

    def Update(self, charID, fg = 'white'):
        self.charID = charID
        self.charID_noDIG = re.sub(r'[0-9]', '', self.charID)
        self.config(text=self.charID_noDIG,foreground=fg)
