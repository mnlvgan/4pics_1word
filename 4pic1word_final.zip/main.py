from tkinter import *
from tkinter import messagebox
from game_modules import *
import random
import os
import re


#STORES ALL GAME LEVEL OBJECT ALL AT ONCE INTO A DICTIOANARY
level_Dict = {}
with open(f'{os.getcwd()}\\pics\\picList.txt', 'r') as f:
    for x in f:
        x = x.strip().split(';')
        level_Dict[x[0]] = GameLevel(levelNum=x[0], answer=x[1])

#ROOT WINDOW TO HOLD THE MAIN FRAME
class Window(Tk):
    def __init__(self):
        super().__init__()
        self.resizable(width=False, height=False)
        self.config(bg='#212737')
        self.geometry("500x700")
        self.title('4 Pics 1 Word : Khodie Rion Malig')
        self.coins, self.level = 100, 1
        self.revCharIndex_List = []
        try:
            with open('UserSaveFile.txt', 'r') as f:
                f = f.read().split(';')
                if f[2] != '':
                    f[2]=f[2].split(',')
                    self.revCharIndex_List = [int(x) if len(x) == 1 else str(x) for x in f[2]]
                self.coins, self.level = int(f[1]), int(f[0])
        except:
            with open('UserSaveFile.txt', 'w') as w:
                w.write(f'1;100;')
                print('Writing Save File')

        self.progressFrame = ProgressBar(master=self, level= self.level, coins=self.coins)
        self.progressFrame.pack(pady=20)

        #MAIN GAME FRAME
        self.game_Frame = MainFrame(master=self, level=level_Dict[f'{self.level}'])
        self.game_Frame.pack()

        self.protocol("WM_DELETE_WINDOW", self.on_exit)

    def on_exit(self):
        if len(self.revCharIndex_List) != 0:
            self.ext_msg = messagebox.askyesnocancel(title='Exiting Game', message='Do you wish to save your revealed answer?')
            if self.ext_msg == True:
                self.save_progress()
                self.after(1000, lambda: self.destroy())
            elif self.ext_msg == False:
                self.after(500, lambda: self.destroy())
        else:
            self.after(500, lambda: self.destroy())

    def save_progress(self):
        with open('UserSaveFile.txt', 'w') as f:
            test = ''.join(re.sub(r'[\[\]\s+]', '', str(self.revCharIndex_List)))
            f.write(f'{self.level};{self.coins};{test}')

    def update_Game(self, addLevel = 0, addCoins = 0, isPassed = False, isUpdate_Frame = True, isSave_Progress = True):
        if isPassed == True and self.coins < 10:
            return
        if isSave_Progress == True:
            self.save_progress()
        self.level += addLevel
        self.coins += addCoins
        self.progressFrame.Update(level=self.level, coins=self.coins)
        if isUpdate_Frame == True and self.level <= len(list(level_Dict)):
            self.revCharIndex_List = []
            self.new_game_Frame = MainFrame(master=self, level=level_Dict[f'{self.level}'])
            self.new_game_Frame.pack()
            self.game_Frame.destroy()
            self.game_Frame = self.new_game_Frame
        elif isUpdate_Frame == True and self.level > len(list(level_Dict)):
            MenuPrompt(self).place(x=100, y=100)

class MainFrame(Frame):
    def __init__(self, master, level = GameLevel()):
        super().__init__(master)
        #temporary will delete later
        self.__answer = level.answer
        self.__coins = master.coins
        self.revealedCharIndex_List = master.revCharIndex_List

        self.propagate(0)
        self.config(width=500, height=650, background='#212737')

        self.keySelected_List = [None for _ in range(len(self.__answer))]
        self.tempRevealedChar_List = [None for _ in range(len(self.__answer))]

        #FRAME 1 --> PICTURE FRAME
        frame_1 = Frame(self, width=500, highlightthickness=5)
        frame_1.pack(pady=10)

        self.image = PhotoImage(file=f"{os.getcwd()}\\pics\\{level.answer}.png")
        self.picture_label = Label(master=frame_1, image=self.image).pack()

        #TEXT FIELD POSITIONING
        self.textBox_list = level.create_TextField(master=self)
        for x in range(len(level.answer)):
            self.textBox_list[x].grid(row = 0, column = x)

        #CREATE KEYS
        self.__r = 0
        self.__c = 0

        self.buttons_Dict = level.create_Keys(master=self)
        print(list(self.buttons_Dict))
        for count, x in enumerate(self.buttons_Dict):
            self.buttons_Dict[x].config(command=lambda charVar = x: self.UpdateTextField(charVar=charVar, master=master))
            self.buttons_Dict[x].grid(row=self.__r, column=self.__c)
            self.__c += 1
            if (count + 1) % 6 == 0:
                self.__r += 1
                self.__c = 0

        #REVEAL BUTTON
        self.light_image = PhotoImage(file=f"{os.getcwd()}\\assets\\light_icon.png").subsample(x=7, y=7)
        Button(self, image=self.light_image, background='#212737',border=0, activebackground='#212737',command=lambda: self.UpdateTextField(reveal_oneChar=True, master=master)).place(x=425, y=420)

        #PASS BUTTON
        self.pass_image = PhotoImage(file=f"{os.getcwd()}\\assets\\pass_icon.png").subsample(x=6, y=6)
        Button(self, image=self.pass_image, background='#212737', activebackground='#212737',border=0, command=lambda: master.after(500, lambda: master.update_Game(1, -10, isPassed = True))).pack()

        for i in self.revealedCharIndex_List:
            self.update_RevealedChars(i)
        self.UpdateTextField()

    def update_RevealedChars(self, revChar_Index):
        revealedChar = self.__answer[revChar_Index].upper()
        if revealedChar not in self.tempRevealedChar_List:
            self.tempRevealedChar_List[revChar_Index] = revealedChar
        else:
            self.id = 1
            while f'{revealedChar}{self.id}' in self.tempRevealedChar_List:
                self.id += 1
            self.tempRevealedChar_List[revChar_Index] = f'{revealedChar}{self.id}'

    def ResetTextField(self):
        for index, x in enumerate(self.keySelected_List):
            if x in self.tempRevealedChar_List:
                continue
            #REMOVES DIGITS FOR REPEATING LETTERS
            self.buttons_Dict[x].config(text=re.sub(r'[0-9]', '', x))
            self.textBox_list[index].Update(' ')
            self.keySelected_List[index] = None
    
    def UpdateTextField(self, charVar = None, reveal_oneChar = False, master=None):
        #FOR LETTER REVEAL BUTTON
        if reveal_oneChar == True :
            if len(self.revealedCharIndex_List) < len(self.__answer)//2 and self.__coins >= 2:
                revChar_Index = random.randint(0,len(self.__answer) - 1)
                while revChar_Index in self.revealedCharIndex_List:
                    revChar_Index = random.randint(0,len(self.__answer) - 1)
                self.revealedCharIndex_List.append(revChar_Index)
                self.update_RevealedChars(revChar_Index)
                master.update_Game(addCoins=-2, isUpdate_Frame = False, isSave_Progress = False)
            elif self.__coins < 2:
                RevealPrompt(master=self, msg='Insufficient Coins!').place(x=300, y=700/2)
            else:
                RevealPrompt(master=self, msg='Limit Reached!').place(x=300, y=700/2)
        
        #UPDATES AND DISPLAYS ALREADY REVEALED LETTERS
        for index_RevChar in self.revealedCharIndex_List:
            self.revChar = self.tempRevealedChar_List[index_RevChar]
            #IF THE REVEALED CHARACTER IS NOT ON THE BOXES AND THE INDEX IS OCCUPIED THEN IT RETURNS THE PAST OCCUPANT TO THE KEY CHOICES
            if self.revChar not in self.keySelected_List and self.keySelected_List[index_RevChar] != None:
                #PAST OCCUPANT VARIABLES
                rChar = self.keySelected_List[index_RevChar]
                self.buttons_Dict[rChar]['text'] = re.sub(r'[0-9]','',rChar)
            #ELSE IF REVEALED LETTER IN SELECTED KEYES AND THE REVEALED INDEX IS OCCUPIED AND THE OCCUPANT IS NOT THE RIGHT LETTER, IT MOVES THE REVEALED LETTER TO THE CORRECT BOX
            #THEN IT RETURNS THE PAST OCCUPANT TO THE KEY CHOICES
            elif (self.keySelected_List[index_RevChar] != None and self.keySelected_List[index_RevChar] != self.revChar) and self.revChar in self.keySelected_List:
                #REVEALED LETTER VARIABLE TO BE MOVED | mIndex --> Move Index
                mIndex = self.keySelected_List.index(self.revChar)
                self.textBox_list[mIndex].Update(' ')
                self.keySelected_List[mIndex] = None
                #PAST OCCUPANT VARIABLE | rChar --> Remove Char
                rChar = self.keySelected_List[index_RevChar]
                self.buttons_Dict[rChar]['text'] = re.sub(r'[0-9]','',rChar)
            #ELSE IF THE REVEALED LETTER IS IN SELECTED KEYS AND THE INDEX IS NOT OCCUPIED
            elif self.revChar in self.keySelected_List and self.keySelected_List[index_RevChar] == None:
                #REVEALED LETTER VARIABLE TO BE MOVED
                mIndex = self.keySelected_List.index(self.revChar)
                self.textBox_list[mIndex].Update(' ')
                self.keySelected_List[mIndex] = None
            self.textBox_list[index_RevChar].Update(self.revChar, 'gold')
            self.keySelected_List[index_RevChar] = self.revChar
            self.buttons_Dict[self.revChar]['text'] = ' '
    
        #TEXT FIELD LETTERS UPDATE
        if (charVar != None and charVar not in self.keySelected_List) or reveal_oneChar == True:
            if charVar != None:
                for index in range(len(self.textBox_list)):
                    if self.keySelected_List[index] != None:
                        continue
                    self.textBox_list[index].Update(charVar)
                    self.buttons_Dict[charVar]['text'] = ' '
                    self.keySelected_List[index] = charVar.upper()
                    break
            if None not in self.keySelected_List:
                userAnswer = re.sub(r'[0-9]', '', ''.join(self.keySelected_List))
                if userAnswer == self.__answer.upper():
                    master.after(500, lambda: master.update_Game(1, 10))
                else:
                    self.after(500, self.ResetTextField)
                    print(userAnswer)

app = Window()
app.mainloop()